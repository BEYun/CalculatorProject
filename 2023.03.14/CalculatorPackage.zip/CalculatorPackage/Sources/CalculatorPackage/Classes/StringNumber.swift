//
//  StringNumber.swift
//  
//
//  Created by BEYun on 2023/03/13.
//

import Foundation

public class StringNumber: Inputable {

    public typealias Val = String
    
    public var currentNum: String = "0"
    
    public var state: State = .initial
    
    public func addNum(_ num: String) {
        
        if state == .calculating {
            currentNum = "0"
            state = .ready
        }
        
        switch currentNum {
        case "0":
            currentNum = num
        case "-0":
            currentNum = "-" + num
        default:
            currentNum += num
        }
        
    }
    
    required public init() {}
    
    deinit {
        print("StringNumber Instance deinitialized")
    }
}
