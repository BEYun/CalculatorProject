import Foundation



public class CalculatorPackage<T: Inputable>: Calculatable {

    var inputBox = T()
    
    var firstNum: Double = 0.0
    var secondNum: Double = 0.0
    var currentOp: Operation = .none

    var tempOperation: [Any] = []
    
    var result: Double = 0.0
    
}

extension CalculatorPackage {
    
    func makeCal(_ inputOp: Operation) {
        // MARK: T의 Type이 선언되지 않아 T.Val이라는 연관타입으로 선언되어 타입캐스팅 불가
        // String으로 타입캐스팅 후 Double로 변환, 만약 String이 아닐 시 생각해보기
        guard let str = inputBox.currentNum as? String else { return }
        let num = Double(str) ?? 0.0
        
        if inputBox.state == .ready {
            switch currentOp {
            case .plus, .minus:
                addTempOperation()
                firstNum = result
                secondNum = num
                result = caseOperate(op: currentOp)
                
                if inputOp == .multiply || inputOp == .divide {
                    result = secondNum
                }
            case .multiply, .divide:
                firstNum = result
                secondNum = num
                result = caseOperate(op: currentOp)
                
                if !tempOperation.isEmpty && (inputOp == .plus || inputOp == .minus) {
                    let endIndex = tempOperation.index(before: tempOperation.endIndex)
                    guard let tempNum = tempOperation[tempOperation.startIndex] as? Double else { return }
                    guard let tempOp = tempOperation[endIndex] as? Operation else { return }
                    
                    firstNum = tempNum
                    secondNum = result
                    result = caseOperate(op: tempOp)
                }
            default:
                break
            }
            
            currentOp = inputOp
            inputBox.state = .calculating
            
        } else if inputBox.state == .calculating {
            if inputOp == currentOp {
                return
            }
            
            if inputOp == .plus || inputOp == .minus {
                currentOp = inputOp
            } else {
                
            }
            
        } else {
            result = num
            currentOp = inputOp
            inputBox.state = .calculating
        }
    }
    
    func addTempOperation() {
        if tempOperation.isEmpty {
            tempOperation.append(result)
            tempOperation.append(currentOp)
        } else {
            tempOperation[tempOperation.startIndex] = result
            let endIndex = tempOperation.index(before: tempOperation.endIndex)
            tempOperation[endIndex] = currentOp
        }
    }
    
    func makeEqual() {
        
    }

    func caseOperate(op: Operation) -> Double {
        var result: Double = 0.0
        switch op {
        case .plus:
            result = makeAdd()
        case .minus:
            result = makeSub()
        case .multiply:
            result = makeMul()
        case.divide:
            result = makeDiv()
        default:
            break
        }
        
        return result
    }
    
    func makeAdd() -> Double {
        let result = firstNum + secondNum
        return result
    }
    
    func makeSub() -> Double {
        let result = firstNum - secondNum
        return result
    }
    
    func makeMul() -> Double {
        let result = firstNum * secondNum
        return result
    }
    
    func makeDiv() -> Double {
        let result = firstNum / secondNum
        return result
    }
}

