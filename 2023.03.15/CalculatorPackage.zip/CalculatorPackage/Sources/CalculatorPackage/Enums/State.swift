//
//  State.swift
//  
//
//  Created by BEYun on 2023/03/13.
//

import Foundation

public enum State {
    case initial
    case ready
    case calculating
    case equaled
}
