import Foundation



public class CalculatorPackage<T: Inputable>: Calculatable {

    var inputBox = T()
    
    var firstNum: Double = 0.0
    var secondNum: Double = 0.0
    var currentOp: Operation = .none

    var tempOperation: [Any] = []
    
    var result: Double = 0.0
    
}

extension CalculatorPackage {
    
    func makeCal(_ op: Operation) {
        //MARK: T의 Type이 선언되지 않아 T.Val이라는 연관타입으로 선언되어 타입캐스팅 불가
        // String으로 타입캐스팅 후 Double로 변환, 만약 String이 아닐 시 생각해보기
        guard let str = inputBox.currentNum as? String else { return }
        let num = Double(str) ?? 0.0
        
        if inputBox.state == .initial {
            currentOp = op
            firstNum = num
        } else if inputBox.state == .ready {
            secondNum = num
            switch op {
            case .plus:
                makeAdd()
            case .minus:
                makeSub()
            case .multiply:
                makeMul()
            case.divide:
                makeDiv()
            default:
                break
            }
        }
        inputBox.state = .calculating
        print(inputBox.state)
        currentOp = op
    }
    
    func makeAdd() {
        let resultNum = firstNum + secondNum
        result = resultNum
    }
    
    func makeSub() {
        let resultNum = firstNum - secondNum
        result = resultNum
    }
    
    func makeMul() {
        let resultNum = firstNum * secondNum
        result = resultNum
    }
    
    func makeDiv() {
        let resultNum = firstNum / secondNum
        result = resultNum
    }
}
