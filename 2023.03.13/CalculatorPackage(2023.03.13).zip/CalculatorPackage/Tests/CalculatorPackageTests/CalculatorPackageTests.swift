import XCTest
@testable import CalculatorPackage

final class CalculatorPackageTests: XCTestCase {
    
    var test: CalculatorPackage<StringNumber> = CalculatorPackage()
    
    // addNum 메소드 테스트
    func testAddNumber() throws {
        
        test.inputBox.addNum("-1")
        test.inputBox.addNum("0")
        test.inputBox.addNum("3")
        
        let result = test.inputBox.currentNum
        
        XCTAssertEqual(result, "-103")
        
    }
    
    // makeCal 메소드 테스트
    func testMakeCal() throws {
        test.inputBox.addNum("-1")
        test.inputBox.addNum("0")
        test.inputBox.addNum("3")
        test.makeCal(.plus)

        XCTAssertEqual(test.firstNum, -103.0)
        XCTAssertEqual(test.currentOp, .plus)
        
        test.inputBox.addNum("3")
        XCTAssertEqual(test.inputBox.currentNum, "3")
    }
}
