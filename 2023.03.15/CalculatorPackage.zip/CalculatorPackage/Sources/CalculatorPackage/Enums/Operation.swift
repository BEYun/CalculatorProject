//
//  Operation.swift
//  
//
//  Created by BEYun on 2023/03/13.
//

import Foundation

public enum Operation {
    case none
    case plus
    case minus
    case multiply
    case divide
}
