import XCTest
@testable import CalculatorPackage

final class CalculatorPackageTests: XCTestCase {
    
    var test: CalculatorPackage<StringNumber> = CalculatorPackage()
    
    // addNum 메소드 테스트
    func testAddNumber() throws {
        
        test.inputBox.addNum("-1")
        test.inputBox.addNum("0")
        test.inputBox.addNum(".")
        test.inputBox.addNum("3")
        test.inputBox.addNum("0")
        test.inputBox.addNum("0")
        test.inputBox.addNum("0")
        
        let result = test.inputBox.currentNum
        
        XCTAssertEqual(result, "-10.3000")
        
    }
    
    // makeCal 메소드 테스트
    func testMakeCal() throws {
        // 1+1+1*5+5*5*5*5 =
        test.inputBox.addNum("1")
        test.makeCal(.plus)
        test.inputBox.addNum("1")
        test.makeCal(.plus)
        test.inputBox.addNum("1")
        test.makeCal(.multiply)
        test.inputBox.addNum("5")
        test.makeCal(.plus)
        test.inputBox.addNum("5")
        test.makeCal(.multiply)
        test.inputBox.addNum("5")
        test.makeCal(.multiply)
        test.inputBox.addNum("5")
        test.makeCal(.multiply)
        test.inputBox.addNum("5")
        test.makeCal(.plus)
        
        print(test.tempOperation)
        XCTAssertEqual(test.result, 632.0)
    }
}
