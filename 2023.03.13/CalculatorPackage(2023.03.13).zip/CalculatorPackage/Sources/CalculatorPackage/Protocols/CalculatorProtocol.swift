//
//  CalculatorProtocol.swift
//  
//
//  Created by BEYun on 2023/03/10.
//

import Foundation

public protocol Inputable {
    
    associatedtype Val
    
    var currentNum: Val { get set }
    
    var state: State { get set }
    
    func addNum(_ num: Val)
    
    init()
    
}

protocol Calculatable: Adding, Substracting, Multiplying, Dividing {
    // 연산자, 피연산자, 임시 저장
    var firstNum: Double { get set }
    var secondNum: Double { get set}
    var currentOp: Operation { get set }
    var tempOperation: [Any] { get set }
}

protocol Adding {
    func makeAdd()
}

protocol Substracting {
    func makeSub()
}

protocol Multiplying {
    func makeMul()
}

protocol Dividing {
    func makeDiv()
}




